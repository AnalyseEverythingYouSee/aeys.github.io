module.exports = {
    get handle() {
        return require('./handle');
    },

    get input() {
        return require('./input');
    },

    get output() {
        return require('./output');
    }
};
